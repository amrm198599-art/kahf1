# ملفات البناء والنشر — سورة الكهف (Groovy DSL)

## `.github/workflows/build.yml`

```yaml
name: Build APK & AAB

on:
  push:
    branches: [main, master]
    tags: ['v*']
  pull_request:
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'

      - name: Decode keystore (إن وُجدت الأسرار)
        env:
          KEYSTORE_BASE64: ${{ secrets.KEYSTORE_BASE64 }}
        run: |
          if [ -n "$KEYSTORE_BASE64" ]; then
            echo "$KEYSTORE_BASE64" | base64 -d > "$RUNNER_TEMP/release.jks"
            echo "KEYSTORE_FILE=$RUNNER_TEMP/release.jks" >> "$GITHUB_ENV"
          else
            echo "::warning::KEYSTORE_BASE64 غير موجود، سيتم التوقيع بمفتاح debug (للتجربة فقط وليس للنشر)."
          fi

      - name: Build release APK + AAB
        env:
          KEYSTORE_PASSWORD: ${{ secrets.KEYSTORE_PASSWORD }}
          KEY_ALIAS: ${{ secrets.KEY_ALIAS }}
          KEY_PASSWORD: ${{ secrets.KEY_PASSWORD }}
          VERSION_CODE: ${{ github.run_number }}
          VERSION_NAME: ${{ github.ref_type == 'tag' && github.ref_name || format('1.0.{0}', github.run_number) }}
        run: gradle assembleRelease bundleRelease --stacktrace

      - name: Rename outputs
        run: |
          mkdir -p dist
          cp app/build/outputs/apk/release/*.apk dist/SuratAlKahf.apk
          cp app/build/outputs/bundle/release/*.aab dist/SuratAlKahf.aab

      - uses: actions/upload-artifact@v4
        with:
          name: SuratAlKahf-release
          path: dist/*

      - name: Publish GitHub Release
        if: startsWith(github.ref, 'refs/tags/v')
        uses: softprops/action-gh-release@v2
        with:
          files: |
            dist/SuratAlKahf.apk
            dist/SuratAlKahf.aab
```

## `.github/workflows/pages.yml`

```yaml
name: Publish privacy policy (GitHub Pages)

on:
  push:
    branches: [main, master]
    paths: ['docs/**']
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: true

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v3
        with:
          path: docs
      - id: deployment
        uses: actions/deploy-pages@v4
```

## `settings.gradle`

```groovy
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "SuratAlKahf"
include(":app")
```

## `build.gradle`

```groovy
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
```

## `gradle.properties`

```properties
org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8
org.gradle.parallel=true
org.gradle.caching=true
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
```

## `gradle/libs.versions.toml`

```toml
[versions]
agp = "8.7.3"
kotlin = "2.0.21"
composeBom = "2024.10.01"
coreKtx = "1.15.0"
activityCompose = "1.9.3"
lifecycle = "2.8.7"
media3 = "1.4.1"
work = "2.9.1"

[libraries]
androidx-core-ktx = { module = "androidx.core:core-ktx", version.ref = "coreKtx" }
androidx-activity-compose = { module = "androidx.activity:activity-compose", version.ref = "activityCompose" }
androidx-lifecycle-viewmodel-compose = { module = "androidx.lifecycle:lifecycle-viewmodel-compose", version.ref = "lifecycle" }
androidx-lifecycle-runtime-compose = { module = "androidx.lifecycle:lifecycle-runtime-compose", version.ref = "lifecycle" }
compose-bom = { module = "androidx.compose:compose-bom", version.ref = "composeBom" }
compose-ui = { module = "androidx.compose.ui:ui" }
compose-foundation = { module = "androidx.compose.foundation:foundation" }
compose-material3 = { module = "androidx.compose.material3:material3" }
compose-icons-extended = { module = "androidx.compose.material:material-icons-extended" }
media3-exoplayer = { module = "androidx.media3:media3-exoplayer", version.ref = "media3" }
media3-session = { module = "androidx.media3:media3-session", version.ref = "media3" }
media3-transformer = { module = "androidx.media3:media3-transformer", version.ref = "media3" }
media3-effect = { module = "androidx.media3:media3-effect", version.ref = "media3" }
work-runtime = { module = "androidx.work:work-runtime-ktx", version.ref = "work" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
```

## `gradle/wrapper/gradle-wrapper.properties`

```properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

## `app/build.gradle`

```groovy
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// التوقيع: يقرأ من متغيرات البيئة (GitHub Secrets). لو غير موجودة يُوقَّع بمفتاح debug للتجربة فقط.
def ksPath = System.getenv("KEYSTORE_FILE")
def ksFile = (ksPath != null && !ksPath.trim().isEmpty()) ? file(ksPath) : null
def hasKs = (ksFile != null && ksFile.exists())
def vCode = Integer.parseInt(System.getenv("VERSION_CODE") ?: "1")
def vName = System.getenv("VERSION_NAME") ?: "1.0.0"

android {
    namespace "com.alkahf.app"
    compileSdk 35

    defaultConfig {
        applicationId "com.alkahf.app"
        minSdk 26
        targetSdk 35
        versionCode vCode
        versionName vName
    }

    signingConfigs {
        if (hasKs) {
            release {
                storeFile ksFile
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS")
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"
            signingConfig hasKs ? signingConfigs.release : signingConfigs.debug
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose true
    }
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
    bundle {
        language {
            enableSplit = false
        }
    }
    packaging {
        resources {
            excludes.add("/META-INF/{AL2.0,LGPL2.1}")
        }
    }
}

dependencies {
    implementation libs.androidx.core.ktx
    implementation libs.androidx.activity.compose
    implementation libs.androidx.lifecycle.viewmodel.compose
    implementation libs.androidx.lifecycle.runtime.compose
    implementation platform(libs.compose.bom)
    implementation libs.compose.ui
    implementation libs.compose.foundation
    implementation libs.compose.material3
    implementation libs.compose.icons.extended
    implementation libs.media3.exoplayer
    implementation libs.media3.session
    implementation libs.media3.transformer
    implementation libs.media3.effect
    implementation libs.work.runtime
}
```

## `app/proguard-rules.pro`

```
# Media3 / WorkManager / Compose تضيف قواعدها تلقائياً (consumer rules).
-keepattributes *Annotation*, SourceFile, LineNumberTable
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**
```

## `.gitignore`

```
*.iml
.gradle/
local.properties
.idea/
build/
captures/
*.jks
*.keystore
keystore.properties
```
