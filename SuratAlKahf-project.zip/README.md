# سورة الكهف — تطبيق أندرويد

Kotlin + Jetpack Compose + Material 3 • minSdk 26 • targetSdk/compileSdk 35 • اسم الحزمة `com.alkahf.app`

## الميزات
- قراءة السورة (110 آية) مع تكبير/تصغير الخط وحفظ آخر موضع.
- التفسير الميسر لكل آية.
- استماع بـ 27 قارئاً (مرتل ومجود) آيةً بآية: بث مباشر أو تنزيل (نسبة التقدم + اسم القارئ) ثم تشغيل أوفلاين، مع تشغيل في الخلفية وإشعار تحكم وتمييز الآية الحالية.
- إنشاء فيديو mp4 لأي آية (أو حتى ١٠ آيات) بصوت القارئ وخلفية (ألوان أو صورة من الهاتف) يُحفظ في معرض الهاتف.
- 6 قصص بالكرتون (رسوم متحركة بالرموز + نص + قراءة صوتية عبر TTS).
- أخضر + ذهبي + كريمي، RTL، وضع داكن.

> النص والتفاسير تُحمّل من الإنترنت **مرة واحدة عند أول فتح** (api.alquran.cloud) ثم تُحفظ وتعمل أوفلاين. الصوت من everyayah.com.

## البناء على GitHub (بدون أي شيء على جهازك)
1. أنشئ ريبو جديد وارفع كل محتويات هذا المجلد.
2. أنشئ مفتاح التوقيع (مرة واحدة فقط، واحتفظ بنسخة منه ومن كلمة السر!):
   ```bash
   ./scripts/generate-keystore.sh kahf
   ```
3. من Settings → Secrets and variables → Actions أضف:
   `KEYSTORE_BASE64` ، `KEYSTORE_PASSWORD` ، `KEY_ALIAS` ، `KEY_PASSWORD`
4. أي push على `main` يبني APK و AAB ويرفعهما في Actions → Artifacts.
5. للإصدار الرسمي: `git tag v1.0.0 && git push origin v1.0.0` فيظهران في Releases.

> لا يوجد `gradlew`/`gradle-wrapper.jar` (ملف ثنائي). الـ workflow يستخدم Gradle 8.9 مباشرة. لتشغيل محلي: `gradle wrapper --gradle-version 8.9` ثم `./gradlew assembleRelease bundleRelease`.

## سياسة الخصوصية
- داخل التطبيق: الإعدادات ← سياسة الخصوصية.
- صفحة ويب: فعّل GitHub Pages (Settings → Pages → Source: GitHub Actions) وسيكون الرابط `https://USERNAME.github.io/REPO/` — استخدمه في Google Play.
- عدّل `[ضع بريدك الإلكتروني هنا]` في `ui/Texts.kt` و `docs/index.html` و `PRIVACY_POLICY.md`.

## النشر على Google Play (خطوات مختصرة)
1. حساب Play Console (رسوم لمرة واحدة 25$).
2. Create app → الاسم «سورة الكهف» • اللغة العربية • تطبيق • مجاني.
3. App content: رابط سياسة الخصوصية، Ads = لا، Data safety = لا يجمع بيانات (بيانات الشبكة فقط للتنزيل)، تصنيف المحتوى (استبيان)، الفئة المستهدفة: 13+.
4. Store listing: وصف قصير وطويل، أيقونة 512×512 (`play_store_icon_512.png`)، صورة مميزة 1024×500، لقطات شاشة (2+ للهاتف).
5. Production (أو Internal testing أولاً) → ارفع `SuratAlKahf.aab` → Review → Rollout. (الحسابات الشخصية الجديدة تتطلب اختباراً مغلقاً بـ 12 مختبِراً لمدة 14 يوماً قبل الإنتاج.)
6. فعّل Play App Signing (الافتراضي)؛ مفتاحك هو مفتاح الرفع.

## تعديلات سريعة
- القرّاء: `data/Reciters.kt` (id = اسم المجلد في everyayah.com).
- القصص: `ui/StoriesData.kt` • الألوان: `ui/Components.kt`.
- خط المصحف: ضع ملف خط (مثل Amiri Quran) في `res/font` واستبدل `FontFamily.Serif`.
