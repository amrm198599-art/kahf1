# Media3 / WorkManager / Compose تضيف قواعدها تلقائياً (consumer rules).
-keepattributes *Annotation*, SourceFile, LineNumberTable
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**
