package com.alkahf.app

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.alkahf.app.audio.AudioStore
import com.alkahf.app.audio.DownloadWorker
import com.alkahf.app.audio.PlaybackService
import com.alkahf.app.data.AYAH_COUNT
import com.alkahf.app.data.ContentKind
import com.alkahf.app.data.ContentRepository
import com.alkahf.app.data.Load
import com.alkahf.app.data.Reciter
import com.alkahf.app.data.Reciters
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

data class DlState(val running: Boolean = false, val progress: Int = 0, val failed: Boolean = false)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val repo = ContentRepository(app)
    private val ctx: Application get() = getApplication()

    // ---------- المحتوى ----------
    val contents = mutableStateMapOf<ContentKind, Load>()
    var fontSize by mutableIntStateOf(prefs.fontSize); private set
    var themeMode by mutableIntStateOf(prefs.themeMode); private set
    var tafsirKind by mutableStateOf(ContentKind.MUYASSAR)
    var readJump by mutableIntStateOf(-1)
    var tafsirJump by mutableIntStateOf(-1)

    fun setFont(v: Int) { fontSize = v.coerceIn(18, 48); prefs.fontSize = fontSize }
    fun setTheme(v: Int) { themeMode = v; prefs.themeMode = v }

    fun ensure(kind: ContentKind) {
        val c = contents[kind]
        if (c is Load.Ok || c == Load.Loading) return
        reload(kind)
    }

    fun reload(kind: ContentKind) {
        contents[kind] = Load.Loading
        viewModelScope.launch {
            contents[kind] = try {
                Load.Ok(repo.load(kind))
            } catch (e: Exception) {
                Load.Err("تعذّر التحميل. تأكد من الاتصال بالإنترنت ثم أعد المحاولة.\n(يُحفظ بعدها على الجهاز ويعمل بدون إنترنت)")
            }
        }
    }

    // ---------- التنزيلات ----------
    val dl = mutableStateMapOf<String, DlState>()
    val counts = mutableStateMapOf<String, Int>()

    private fun refreshCounts() {
        Reciters.all.forEach { counts[it.id] = AudioStore.count(ctx, it.id) }
    }

    private fun onWork(list: List<WorkInfo>) {
        val map = HashMap<String, DlState>()
        for (w in list) {
            val id = w.tags.firstOrNull { it.startsWith("r_") }?.removePrefix("r_") ?: continue
            val st: DlState = when (w.state) {
                WorkInfo.State.RUNNING, WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED ->
                    DlState(true, w.progress.getInt("p", 0), false)
                WorkInfo.State.FAILED -> DlState(false, 0, true)
                else -> continue
            }
            val cur = map[id]
            if (cur == null || (st.running && !cur.running)) map[id] = st
        }
        dl.clear()
        dl.putAll(map)
        refreshCounts()
    }

    fun startDownload(r: Reciter) {
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(workDataOf("id" to r.id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, 20, TimeUnit.SECONDS)
            .addTag("dl")
            .addTag("r_${r.id}")
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("dl_${r.id}", ExistingWorkPolicy.REPLACE, req)
    }

    fun cancelDownload(r: Reciter) {
        WorkManager.getInstance(ctx).cancelUniqueWork("dl_${r.id}")
    }

    fun deleteAudio(r: Reciter) {
        cancelDownload(r)
        AudioStore.delete(ctx, r)
        if (activeReciter == r.id) stopPlayer()
        refreshCounts()
    }

    // ---------- المشغّل ----------
    var activeReciter by mutableStateOf<String?>(null); private set
    var currentAyah by mutableIntStateOf(0); private set
    var isPlaying by mutableStateOf(false); private set
    var speed by mutableFloatStateOf(1f); private set
    var repeatAll by mutableStateOf(false); private set

    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = syncFromPlayer()
        override fun onIsPlayingChanged(isPlaying: Boolean) = syncFromPlayer()
        override fun onPlaybackStateChanged(playbackState: Int) = syncFromPlayer()
    }

    fun connectPlayer() {
        if (controller != null || future != null) return
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                syncFromPlayer()
            } catch (e: Exception) {
                future = null
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun syncFromPlayer() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        speed = c.playbackParameters.speed
        repeatAll = c.repeatMode == Player.REPEAT_MODE_ALL
        val item = c.currentMediaItem
        if (item == null) {
            activeReciter = null
            currentAyah = 0
        } else {
            val id = item.mediaId
            val cut = id.lastIndexOf('_')
            if (cut > 0) {
                activeReciter = id.substring(0, cut)
                currentAyah = id.substring(cut + 1).toIntOrNull() ?: 0
            }
        }
    }

    fun play(r: Reciter, startAyah: Int = 1) {
        val c = controller ?: return
        prefs.reciterId = r.id
        val items = (1..AYAH_COUNT).map { n ->
            val f = AudioStore.file(ctx, r.id, n)
            val uri = if (f.exists()) Uri.fromFile(f) else Uri.parse(Reciters.ayahUrl(r, n))
            MediaItem.Builder()
                .setMediaId("${r.id}_$n")
                .setUri(uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("سورة الكهف - آية $n")
                        .setArtist(r.name)
                        .build()
                )
                .build()
        }
        c.setMediaItems(items, (startAyah - 1).coerceIn(0, AYAH_COUNT - 1), 0L)
        c.prepare()
        c.play()
        activeReciter = r.id
        currentAyah = startAyah
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun prev() { controller?.seekToPreviousMediaItem() }

    fun cycleSpeed() {
        val c = controller ?: return
        val steps = listOf(1f, 1.25f, 1.5f, 0.75f)
        val i = steps.indexOfFirst { it == speed }
        c.setPlaybackSpeed(steps[(i + 1) % steps.size])
        speed = c.playbackParameters.speed
    }

    fun toggleRepeat() {
        val c = controller ?: return
        c.repeatMode = if (c.repeatMode == Player.REPEAT_MODE_ALL) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL
        repeatAll = c.repeatMode == Player.REPEAT_MODE_ALL
    }

    fun stopPlayer() {
        controller?.run { stop(); clearMediaItems() }
        activeReciter = null
        currentAyah = 0
        isPlaying = false
    }

    init {
        refreshCounts()
        WorkManager.getInstance(app).getWorkInfosByTagFlow("dl")
            .onEach { onWork(it) }
            .launchIn(viewModelScope)
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
        super.onCleared()
    }
}
