package com.alkahf.app

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("kahf_prefs", Context.MODE_PRIVATE)

    var fontSize: Int
        get() = sp.getInt("font", 28)
        set(v) = sp.edit().putInt("font", v).apply()

    /** رقم العنصر في قائمة القراءة (0 = البسملة، n = الآية n) */
    var lastAyah: Int
        get() = sp.getInt("last", 0)
        set(v) = sp.edit().putInt("last", v).apply()

    var reciterId: String
        get() = sp.getString("reciter", "Alafasy_128kbps") ?: "Alafasy_128kbps"
        set(v) = sp.edit().putString("reciter", v).apply()

    /** 0 = حسب النظام، 1 = فاتح، 2 = داكن */
    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()
}
