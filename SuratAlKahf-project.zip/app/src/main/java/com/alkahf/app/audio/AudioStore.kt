package com.alkahf.app.audio

import android.content.Context
import com.alkahf.app.data.AYAH_COUNT
import com.alkahf.app.data.Reciter
import java.io.File
import java.util.Locale

object AudioStore {
    fun dir(ctx: Context, id: String) = File(ctx.applicationContext.filesDir, "audio/$id")

    fun file(ctx: Context, id: String, ayah: Int) =
        File(dir(ctx, id), String.format(Locale.US, "%03d.mp3", ayah))

    fun count(ctx: Context, id: String): Int =
        dir(ctx, id).listFiles { f -> f.name.endsWith(".mp3") }?.size ?: 0

    fun isComplete(ctx: Context, id: String) = count(ctx, id) >= AYAH_COUNT

    fun delete(ctx: Context, r: Reciter) {
        dir(ctx, r.id).deleteRecursively()
    }
}
