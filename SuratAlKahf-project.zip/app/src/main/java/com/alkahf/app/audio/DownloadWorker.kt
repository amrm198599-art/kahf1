package com.alkahf.app.audio

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.alkahf.app.data.AYAH_COUNT
import com.alkahf.app.data.Reciters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** ينزّل 110 آية للقارئ، ويستكمل من حيث توقف، ويعيد المحاولة تلقائياً عند انقطاع الشبكة. */
class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private class BadSource(msg: String) : Exception(msg)

    override suspend fun doWork(): Result {
        val id = inputData.getString("id") ?: return Result.failure()
        val reciter = Reciters.byId(id) ?: return Result.failure()
        val dir = AudioStore.dir(applicationContext, id).apply { mkdirs() }

        for (n in 1..AYAH_COUNT) {
            val target = AudioStore.file(applicationContext, id, n)
            if (!target.exists()) {
                try {
                    withContext(Dispatchers.IO) { download(Reciters.ayahUrl(reciter, n), target) }
                } catch (e: BadSource) {
                    return Result.failure(workDataOf("err" to (e.message ?: "bad source")))
                } catch (e: IOException) {
                    return if (runAttemptCount >= 10) Result.failure() else Result.retry()
                }
            }
            setProgress(workDataOf("p" to (n * 100 / AYAH_COUNT)))
        }
        return Result.success()
    }

    private fun download(url: String, target: File) {
        val tmp = File(target.parentFile, target.name + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        try {
            val code = c.responseCode
            if (code == 404) throw BadSource("404")
            if (code != 200) throw IOException("HTTP $code")
            c.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (tmp.length() == 0L) throw IOException("empty")
            if (!tmp.renameTo(target)) throw IOException("rename failed")
        } finally {
            c.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }
}
