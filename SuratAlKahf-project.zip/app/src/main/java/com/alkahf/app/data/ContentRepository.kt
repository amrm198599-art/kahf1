package com.alkahf.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

const val AYAH_COUNT = 110

data class AyahItem(val n: Int, val text: String)

enum class ContentKind(val file: String, val url: String) {
    TEXT("text.json", "https://api.alquran.cloud/v1/surah/18/quran-uthmani"),
    MUYASSAR("muyassar.json", "https://api.alquran.cloud/v1/surah/18/ar.muyassar"),
}

sealed interface Load {
    data object Loading : Load
    data class Err(val msg: String) : Load
    data class Ok(val items: List<AyahItem>) : Load
}

/** يحمّل النص والتفاسير مرة واحدة من الإنترنت ثم يحفظها محلياً لتعمل أوفلاين. */
class ContentRepository(ctx: Context) {
    private val dir = File(ctx.applicationContext.filesDir, "content").apply { mkdirs() }

    suspend fun load(kind: ContentKind): List<AyahItem> = withContext(Dispatchers.IO) {
        val cache = File(dir, kind.file)
        if (cache.exists()) {
            runCatching { readCache(cache) }.getOrNull()?.let { if (it.isNotEmpty()) return@withContext it }
        }
        val raw = httpGet(kind.url)
        val items = parseRemote(raw, kind)
        if (kind == ContentKind.TEXT && items.size != AYAH_COUNT) {
            throw IllegalStateException("بيانات غير مكتملة")
        }
        if (items.isEmpty()) throw IllegalStateException("لا توجد بيانات")
        writeCache(cache, items)
        items
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun parseRemote(raw: String, kind: ContentKind): List<AyahItem> {
        val root = JSONObject(raw)
        val arr = root.optJSONObject("data")?.optJSONArray("ayahs") ?: root.optJSONArray("ayahs")
            ?: return emptyList()
        val out = ArrayList<AyahItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val n = if (o.has("numberInSurah")) o.getInt("numberInSurah") else o.optInt("ayah", i + 1)
            var t = o.optString("text", "").trim()
            if (kind == ContentKind.TEXT && n == 1 && t.startsWith("بِسْمِ")) {
                // بعض الإصدارات تضيف البسملة قبل الآية الأولى: نحذف الكلمات الأربع الأولى
                t = t.split(" ").drop(4).joinToString(" ").trim()
            }
            out.add(AyahItem(n, t))
        }
        return out.sortedBy { it.n }
    }

    private fun writeCache(f: File, items: List<AyahItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("n", it.n).put("t", it.text)) }
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(arr.toString(), Charsets.UTF_8)
        tmp.renameTo(f)
    }

    private fun readCache(f: File): List<AyahItem> {
        val arr = JSONArray(f.readText(Charsets.UTF_8))
        return List(arr.length()) { i -> arr.getJSONObject(i).let { AyahItem(it.getInt("n"), it.getString("t")) } }
    }
}
