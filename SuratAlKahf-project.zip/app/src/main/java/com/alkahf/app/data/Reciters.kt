package com.alkahf.app.data

import java.util.Locale

data class Reciter(val id: String, val name: String, val style: String)

/** id = اسم المجلد على everyayah.com (يمكن تعديل القائمة بسهولة من هنا). */
object Reciters {
    const val MURATTAL = "مرتل"
    const val MUJAWWAD = "مجود"

    val all: List<Reciter> = listOf(
        Reciter("Alafasy_128kbps", "مشاري العفاسي", MURATTAL),
        Reciter("Abdul_Basit_Murattal_192kbps", "عبد الباسط عبد الصمد", MURATTAL),
        Reciter("Abdul_Basit_Mujawwad_128kbps", "عبد الباسط عبد الصمد", MUJAWWAD),
        Reciter("Abdurrahmaan_As-Sudais_192kbps", "عبد الرحمن السديس", MURATTAL),
        Reciter("Saood_ash-Shuraym_128kbps", "سعود الشريم", MURATTAL),
        Reciter("MaherAlMuaiqly128kbps", "ماهر المعيقلي", MURATTAL),
        Reciter("Hudhaify_128kbps", "علي الحذيفي", MURATTAL),
        Reciter("Husary_128kbps", "محمود خليل الحصري", MURATTAL),
        Reciter("Husary_Mujawwad_128kbps", "محمود خليل الحصري", MUJAWWAD),
        Reciter("Minshawy_Murattal_128kbps", "محمد صديق المنشاوي", MURATTAL),
        Reciter("Minshawy_Mujawwad_192kbps", "محمد صديق المنشاوي", MUJAWWAD),
        Reciter("Mustafa_Ismail_48kbps", "مصطفى إسماعيل", MUJAWWAD),
        Reciter("Mohammad_al_Tablaway_128kbps", "محمد الطبلاوي", MUJAWWAD),
        Reciter("Ghamadi_40kbps", "سعد الغامدي", MURATTAL),
        Reciter("Abu_Bakr_Ash-Shaatree_128kbps", "أبو بكر الشاطري", MURATTAL),
        Reciter("Hani_Rifai_192kbps", "هاني الرفاعي", MURATTAL),
        Reciter("Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaby.com", "أحمد بن علي العجمي", MURATTAL),
        Reciter("Muhammad_Ayyoub_128kbps", "محمد أيوب", MURATTAL),
        Reciter("Muhammad_Jibreel_128kbps", "محمد جبريل", MURATTAL),
        Reciter("Nasser_Alqatami_128kbps", "ناصر القطامي", MURATTAL),
        Reciter("Salaah_AbdulRahman_Bukhatir_128kbps", "صلاح بوخاطر", MURATTAL),
        Reciter("Yasser_Ad-Dussary_128kbps", "ياسر الدوسري", MURATTAL),
        Reciter("Abdullah_Basfar_192kbps", "عبد الله بصفر", MURATTAL),
        Reciter("Ali_Jaber_64kbps", "علي جابر", MURATTAL),
        Reciter("Khaalid_Abdullaah_al-Qahtaanee_192kbps", "خالد القحطاني", MURATTAL),
        Reciter("Fares_Abbad_64kbps", "فارس عباد", MURATTAL),
        Reciter("Abdullaah_3awwaad_Al-Juhaynee_128kbps", "عبد الله عواد الجهني", MURATTAL),
        Reciter("Ibrahim_Akhdar_32kbps", "إبراهيم الأخضر", MURATTAL),
    )

    fun byId(id: String): Reciter? = all.firstOrNull { it.id == id }

    fun ayahUrl(r: Reciter, ayah: Int): String =
        String.format(Locale.US, "https://everyayah.com/data/%s/018%03d.mp3", r.id, ayah)
}
