package com.alkahf.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.alkahf.app.MainViewModel

private data class Tab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("الرئيسية", Icons.Filled.Home),
    Tab("القراءة", Icons.Filled.MenuBook),
    Tab("الاستماع", Icons.Filled.Headphones),
    Tab("التفسير", Icons.Filled.Description),
    Tab("القصص", Icons.Filled.AutoStories),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KahfApp(vm: MainViewModel) {
    KahfTheme(vm.themeMode) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var overlay by rememberSaveable { mutableStateOf<String?>(null) }

        BackHandler(enabled = overlay != null || tab != 0) {
            if (overlay == "privacy") overlay = "settings"
            else if (overlay != null) overlay = null
            else tab = 0
        }

        val title = when (overlay) {
            "settings" -> "الإعدادات"
            "privacy" -> "سياسة الخصوصية"
            else -> if (tab == 0) "سورة الكهف" else tabs[tab].label
        }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text(title, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif) },
                    navigationIcon = {
                        if (overlay != null) {
                            IconButton({ overlay = if (overlay == "privacy") "settings" else null }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع")
                            }
                        }
                    },
                    actions = {
                        if (overlay == null) {
                            IconButton({ overlay = "settings" }) { Icon(Icons.Filled.Settings, "الإعدادات") }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Green, titleContentColor = Gold,
                        navigationIconContentColor = Gold, actionIconContentColor = Gold,
                    ),
                )
            },
            bottomBar = {
                Column {
                    MiniPlayer(vm)
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        tabs.forEachIndexed { i, t ->
                            NavigationBarItem(
                                selected = overlay == null && tab == i,
                                onClick = { overlay = null; tab = i },
                                icon = { Icon(t.icon, t.label) },
                                label = { Text(t.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Cream,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = GreenLight,
                                ),
                            )
                        }
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (overlay) {
                    "settings" -> SettingsScreen(vm, openPrivacy = { overlay = "privacy" })
                    "privacy" -> PrivacyScreen()
                    else -> when (tab) {
                        0 -> HomeScreen(vm) { tab = it }
                        1 -> ReaderScreen(vm) { n -> vm.tafsirJump = n; tab = 3 }
                        2 -> ListenScreen(vm)
                        3 -> TafsirScreen(vm)
                        else -> StoriesScreen()
                    }
                }
            }
        }
    }
}
