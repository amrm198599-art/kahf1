package com.alkahf.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import com.alkahf.app.MainViewModel
import com.alkahf.app.data.AyahItem
import com.alkahf.app.data.ContentKind
import com.alkahf.app.data.Load

val Green = Color(0xFF0B4D2C)
val GreenLight = Color(0xFF1E7A47)
val Gold = Color(0xFFC9A227)
val Cream = Color(0xFFFBF6E6)
val Ink = Color(0xFF1B2B22)

private val LightScheme = lightColorScheme(
    primary = Green, onPrimary = Cream,
    secondary = Gold, onSecondary = Ink,
    background = Cream, onBackground = Ink,
    surface = Color(0xFFFFFDF5), onSurface = Ink,
    primaryContainer = Color(0xFFDDEBDD), onPrimaryContainer = Green,
    surfaceVariant = Color(0xFFF1EAD0), onSurfaceVariant = Color(0xFF4A5A4F),
    outline = Gold,
)
private val DarkScheme = darkColorScheme(
    primary = Gold, onPrimary = Color(0xFF1B1500),
    secondary = GreenLight, onSecondary = Cream,
    background = Color(0xFF08170E), onBackground = Color(0xFFF3EBD3),
    surface = Color(0xFF0F2417), onSurface = Color(0xFFF3EBD3),
    primaryContainer = Color(0xFF1B3A28), onPrimaryContainer = Gold,
    surfaceVariant = Color(0xFF16301F), onSurfaceVariant = Color(0xFFCFC8B0),
    outline = Gold,
)

@Composable
fun KahfTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        shapes = Shapes(
            small = RoundedCornerShape(14.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp),
        ),
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, content = content)
    }
}

/** زر عصري: حواف دائرية + تدرج أخضر + إطار ذهبي. */
@Composable
fun ModernButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    filled: Boolean = true,
) {
    val shape = RoundedCornerShape(26.dp)
    val bg = if (filled) Brush.horizontalGradient(listOf(Green, GreenLight))
    else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
    val fg = if (filled) Cream else MaterialTheme.colorScheme.primary
    Row(
        modifier
            .clip(shape)
            .background(bg)
            .border(1.5.dp, Gold, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = if (filled) Gold else fg, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = fg, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

/** يحمّل المحتوى (من الإنترنت أول مرة ثم من الذاكرة المحلية) ويعرض الحالة. */
@Composable
fun ContentGate(vm: MainViewModel, kind: ContentKind, body: @Composable (List<AyahItem>) -> Unit) {
    LaunchedEffect(kind) { vm.ensure(kind) }
    when (val s = vm.contents[kind]) {
        null, Load.Loading -> Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.size(12.dp))
            Text("جاري التحميل…")
        }
        is Load.Err -> Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(s.msg, textAlign = TextAlign.Center)
            Spacer(Modifier.size(16.dp))
            ModernButton("إعادة المحاولة", { vm.reload(kind) })
        }
        is Load.Ok -> body(s.items)
    }
}

fun arabicDigits(n: Int): String =
    n.toString().map { '٠' + (it - '0') }.joinToString("")
