package com.alkahf.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.alkahf.app.MainViewModel
import com.alkahf.app.data.AyahItem
import com.alkahf.app.data.Reciters
import com.alkahf.app.video.VideoExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun loadBitmap(ctx: Context, uri: Uri): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExportDialog(vm: MainViewModel, ayahs: List<AyahItem>, startAyah: Int, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ri by remember { mutableIntStateOf(Reciters.all.indexOfFirst { it.id == vm.prefs.reciterId }.coerceAtLeast(0)) }
    var from by remember { mutableStateOf(startAyah.toString()) }
    var to by remember { mutableStateOf(startAyah.toString()) }
    var style by remember { mutableIntStateOf(0) }
    var bgUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) { bgUri = u; style = 3 }
    }

    fun doExport() {
        val a = from.toIntOrNull()
        val b = to.toIntOrNull()
        if (a == null || b == null || a < 1 || b < a || b > 110 || b - a > 9) {
            status = "تحقق من أرقام الآيات (حتى ١٠ آيات في المرة)"
            return
        }
        busy = true
        status = "جاري التجهيز…"
        scope.launch {
            try {
                val sel = ayahs.filter { it.n in a..b }
                val bg = if (style == 3 && bgUri != null) withContext(Dispatchers.IO) { loadBitmap(ctx, bgUri!!) } else null
                VideoExporter.export(ctx, Reciters.all[ri], sel, style, bg) { msg -> withContext(Dispatchers.Main) { status = msg } }
                status = "تم الحفظ في معرض الهاتف (ألبوم SuratAlKahf) ✓"
            } catch (e: Exception) {
                status = "تعذّر إنشاء الفيديو: " + (e.message ?: e.javaClass.simpleName)
            }
            busy = false
        }
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) doExport() else status = "يلزم السماح بالتخزين لحفظ الفيديو في المعرض"
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("إنشاء فيديو للآية") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("القارئ")
                Column {
                    ModernButton("${Reciters.all[ri].name} — ${Reciters.all[ri].style}", { menu = true }, Modifier.fillMaxWidth(), filled = false)
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        Reciters.all.forEachIndexed { i, r ->
                            DropdownMenuItem(text = { Text("${r.name} — ${r.style}") }, onClick = { ri = i; menu = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = from, onValueChange = { from = it.filter(Char::isDigit).take(3) },
                        label = { Text("من آية") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                    OutlinedTextField(
                        value = to, onValueChange = { to = it.filter(Char::isDigit).take(3) },
                        label = { Text("إلى آية") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                }
                Text("الخلفية")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("أخضر", "ليلي", "ذهبي").forEachIndexed { i, n ->
                        FilterChip(selected = style == i, onClick = { style = i }, label = { Text(n) })
                    }
                    FilterChip(
                        selected = style == 3,
                        onClick = { pickImage.launch("image/*") },
                        label = { Text(if (bgUri != null) "صورة مختارة ✓" else "صورة من الهاتف") },
                    )
                }
                if (status.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(status, color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    if (Build.VERSION.SDK_INT < 29 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    ) perm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    else doExport()
                },
            ) { Text(if (busy) "جاري العمل…" else "إنشاء وحفظ في المعرض") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("إغلاق") } },
    )
}
