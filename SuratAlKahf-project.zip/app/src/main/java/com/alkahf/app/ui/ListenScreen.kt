package com.alkahf.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alkahf.app.MainViewModel
import com.alkahf.app.data.AYAH_COUNT
import com.alkahf.app.data.Reciter
import com.alkahf.app.data.Reciters
import java.util.Locale

@Composable
fun ListenScreen(vm: MainViewModel) {
    var filter by remember { mutableStateOf<String?>(null) }
    val list = Reciters.all.filter { filter == null || it.style == filter }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("الكل (${Reciters.all.size})") })
            FilterChip(selected = filter == Reciters.MURATTAL, onClick = { filter = Reciters.MURATTAL }, label = { Text("مرتل") })
            FilterChip(selected = filter == Reciters.MUJAWWAD, onClick = { filter = Reciters.MUJAWWAD }, label = { Text("مجود") })
        }
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(list, key = { it.id }) { r -> ReciterCard(vm, r) }
        }
    }
}

@Composable
private fun ReciterCard(vm: MainViewModel, r: Reciter) {
    val count = vm.counts[r.id] ?: 0
    val st = vm.dl[r.id]
    val done = count >= AYAH_COUNT
    val selected = vm.activeReciter == r.id
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, Gold.copy(alpha = if (selected) 1f else 0.45f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.name, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    AssistChip(onClick = {}, label = { Text(r.style) })
                }
                IconButton({ vm.play(r, 1) }) {
                    Icon(Icons.Filled.PlayArrow, "تشغيل", tint = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.height(6.dp))
            when {
                done -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DownloadDone, null, tint = GreenLight)
                    Spacer(Modifier.width(6.dp))
                    Text("تم التنزيل — يعمل بدون إنترنت", Modifier.weight(1f))
                    IconButton({ vm.deleteAudio(r) }) { Icon(Icons.Filled.Delete, "حذف الصوت") }
                }
                st != null && st.running -> Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (st.progress == 0 && count == 0) "بانتظار الاتصال…"
                            else String.format(Locale.US, "جاري التنزيل… %d%%", st.progress),
                            Modifier.weight(1f)
                        )
                        IconButton({ vm.cancelDownload(r) }) { Icon(Icons.Filled.Close, "إلغاء") }
                    }
                    LinearProgressIndicator(
                        progress = { (count.toFloat() / AYAH_COUNT).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                st != null && st.failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("تعذّر التنزيل", Modifier.weight(1f), color = MaterialTheme.colorScheme.error)
                    TextButton({ vm.startDownload(r) }) { Text("إعادة المحاولة") }
                }
                else -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (count > 0) "منزّل جزئياً ($count/$AYAH_COUNT)" else "غير منزّل",
                        Modifier.weight(1f)
                    )
                    ModernButton(if (count > 0) "استكمال" else "تنزيل", { vm.startDownload(r) }, icon = Icons.Filled.CloudDownload)
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel) {
    val id = vm.activeReciter ?: return
    val r = Reciters.byId(id)
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        border = BorderStroke(1.dp, Gold),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text(r?.name ?: "", fontWeight = FontWeight.Bold, maxLines = 1)
                Text("الآية ${arabicDigits(vm.currentAyah)} من ${arabicDigits(AYAH_COUNT)}")
            }
            IconButton({ vm.prev() }) { Icon(Icons.Filled.SkipNext, "السابقة") }
            IconButton({ vm.togglePlay() }) {
                Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "تشغيل/إيقاف", tint = MaterialTheme.colorScheme.primary)
            }
            IconButton({ vm.next() }) { Icon(Icons.Filled.SkipPrevious, "التالية") }
            TextButton({ vm.cycleSpeed() }) { Text(vm.speed.toString().removeSuffix(".0") + "x") }
            IconButton({ vm.toggleRepeat() }) {
                Icon(Icons.Filled.Repeat, "تكرار", tint = if (vm.repeatAll) Gold else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton({ vm.stopPlayer() }) { Icon(Icons.Filled.Close, "إغلاق") }
        }
    }
}
