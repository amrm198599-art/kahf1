package com.alkahf.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alkahf.app.MainViewModel
import com.alkahf.app.data.ContentKind
import com.alkahf.app.data.Reciters

@Composable
fun HomeScreen(vm: MainViewModel, go: (Int) -> Unit) {
    // قراءة قيم الإعدادات لتظهر آخر حالة عند الرجوع للشاشة
    val p = vm.prefs
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        val shape = RoundedCornerShape(28.dp)
        Column(
            Modifier.fillMaxWidth().clip(shape)
                .background(Brush.verticalGradient(listOf(Green, GreenLight)))
                .border(2.dp, Gold, shape).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("بسم الله الرحمن الرحيم", color = Gold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Text("سورة الكهف", color = Cream, fontSize = 36.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
            Spacer(Modifier.height(6.dp))
            Text("مكية • ١١٠ آية", color = Gold)
            Spacer(Modifier.height(10.dp))
            Text(
                "قراءة وسماع وتفسير وقصص مصوّرة",
                color = Cream.copy(alpha = 0.9f), textAlign = TextAlign.Center,
            )
        }
        ModernButton("متابعة القراءة", { vm.readJump = p.lastAyah; go(1) }, Modifier.fillMaxWidth(), Icons.Filled.MenuBook)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ModernButton("الاستماع", { go(2) }, Modifier.weight(1f), Icons.Filled.Headphones, filled = false)
            ModernButton("التفسير", { go(3) }, Modifier.weight(1f), Icons.Filled.Description, filled = false)
        }
        ModernButton("قصص بالكرتون", { go(4) }, Modifier.fillMaxWidth(), filled = false)

    }
}

@Composable
fun ReaderScreen(vm: MainViewModel, openTafsir: (Int) -> Unit) {
    ContentGate(vm, ContentKind.TEXT) { ayahs ->
        val state = rememberLazyListState(initialFirstVisibleItemIndex = vm.prefs.lastAyah.coerceIn(0, ayahs.size))
        LaunchedEffect(vm.readJump) {
            if (vm.readJump >= 0) { state.scrollToItem(vm.readJump.coerceIn(0, ayahs.size)); vm.readJump = -1 }
        }
        LaunchedEffect(state) {
            snapshotFlow { state.firstVisibleItemIndex }.collect { vm.prefs.lastAyah = it }
        }
        LaunchedEffect(vm.currentAyah, vm.isPlaying) {
            if (vm.isPlaying && vm.currentAyah > 0) state.animateScrollToItem(vm.currentAyah)
        }
        var exportAyah by remember { mutableIntStateOf(-1) }
        Column(Modifier.fillMaxSize()) {
            if (exportAyah > 0) ExportDialog(vm, ayahs, exportAyah) { exportAyah = -1 }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                IconButton({ vm.setFont(vm.fontSize - 2) }) { Icon(Icons.Filled.Remove, "تصغير") }
                Text("حجم الخط ${vm.fontSize}")
                IconButton({ vm.setFont(vm.fontSize + 2) }) { Icon(Icons.Filled.Add, "تكبير") }
            }
            LazyColumn(
                state = state,
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Text(
                        "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
                        Modifier.fillMaxWidth().padding(8.dp),
                        textAlign = TextAlign.Center, color = Gold,
                        fontSize = (vm.fontSize + 2).sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold,
                    )
                }
                items(ayahs, key = { it.n }) { a ->
                    val current = vm.currentAyah == a.n && vm.activeReciter != null
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (current) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, Gold.copy(alpha = if (current) 1f else 0.45f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                a.text + " ﴿" + arabicDigits(a.n) + "﴾",
                                fontSize = vm.fontSize.sp,
                                lineHeight = (vm.fontSize * 1.9f).sp,
                                fontFamily = FontFamily.Serif,
                                textAlign = TextAlign.Justify,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton({
                                    val r = Reciters.byId(vm.prefs.reciterId) ?: Reciters.all.first()
                                    vm.play(r, a.n)
                                }) { Icon(Icons.Filled.PlayArrow, "استماع من هنا", tint = MaterialTheme.colorScheme.primary) }
                                IconButton({ openTafsir(a.n) }) {
                                    Icon(Icons.Filled.Description, "التفسير", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton({ exportAyah = a.n }) {
                                    Icon(Icons.Filled.Movie, "إنشاء فيديو", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TafsirScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "التفسير الميسر",
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        ContentGate(vm, ContentKind.TEXT) { text ->
            ContentGate(vm, vm.tafsirKind) { taf ->
                val map = remember(taf) { taf.associate { it.n to it.text } }
                val state = rememberLazyListState()
                LaunchedEffect(vm.tafsirJump) {
                    if (vm.tafsirJump > 0) { state.scrollToItem((vm.tafsirJump - 1).coerceIn(0, text.size - 1)); vm.tafsirJump = -1 }
                }
                LazyColumn(
                    state = state,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(text, key = { it.n }) { a ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Gold.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(
                                    a.text + " ﴿" + arabicDigits(a.n) + "﴾",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp, lineHeight = 38.sp,
                                )
                                Spacer(Modifier.height(10.dp))
                                val t = map[a.n].orEmpty().ifBlank { "تفسير هذه الآية مدمج مع الآيات المجاورة." }
                                Text(t, fontSize = 18.sp, lineHeight = 30.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
