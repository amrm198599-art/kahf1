package com.alkahf.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alkahf.app.MainViewModel

@Composable
fun SettingsScreen(vm: MainViewModel, openPrivacy: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Gold.copy(alpha = 0.5f)),
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("المظهر والقراءة", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("النظام", "فاتح", "داكن").forEachIndexed { i, label ->
                        FilterChip(selected = vm.themeMode == i, onClick = { vm.setTheme(i) }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("حجم خط القراءة: ${vm.fontSize}")
                Slider(
                    value = vm.fontSize.toFloat(), onValueChange = { vm.setFont(it.toInt()) },
                    valueRange = 18f..48f,
                )
            }
        }
        ModernButton("سياسة الخصوصية", openPrivacy, Modifier.fillMaxWidth(), Icons.Filled.PrivacyTip)
    }
}

@Composable
fun PrivacyScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(Texts.PRIVACY_AR, lineHeight = 26.sp)
        Spacer(Modifier.height(24.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(Texts.PRIVACY_EN) }
    }
}
