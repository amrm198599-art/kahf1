package com.alkahf.app.ui

import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun StoriesScreen() {
    var open by remember { mutableStateOf<Int?>(null) }
    val idx = open
    if (idx != null) {
        BackHandler { open = null }
        StoryViewer(Stories[idx]) { open = null }
        return
    }
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        itemsIndexed(Stories) { i, s ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth().clickable { open = i },
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(64.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Green, GreenLight))),
                        contentAlignment = Alignment.Center,
                    ) { Text(s.icon, fontSize = 32.sp) }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(s.title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(s.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${s.scenes.size} مشاهد", color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StoryViewer(story: Story, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(pageCount = { story.scenes.size })
    var ttsOk by remember { mutableStateOf<Boolean?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            ttsOk = if (status == TextToSpeech.SUCCESS) {
                val r = engine?.setLanguage(Locale("ar"))
                r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            } else false
        }
        tts = engine
        onDispose { engine?.stop(); engine?.shutdown() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(story.title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            ModernButton("استماع", {
                if (ttsOk == true) {
                    tts?.speak(story.scenes[pager.currentPage].text, TextToSpeech.QUEUE_FLUSH, null, "scene")
                } else {
                    Toast.makeText(ctx, "صوت اللغة العربية غير متوفر في الهاتف (فعّله من إعدادات تحويل النص إلى كلام)", Toast.LENGTH_LONG).show()
                }
            }, icon = Icons.AutoMirrored.Filled.VolumeUp, filled = false)
            Spacer(Modifier.width(8.dp))
            ModernButton("رجوع", onClose)
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            SceneView(story.scenes[page])
        }
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            horizontalArrangement = Arrangement.Center,
        ) {
            repeat(story.scenes.size) { i ->
                Box(
                    Modifier.padding(3.dp).size(if (i == pager.currentPage) 12.dp else 8.dp).clip(CircleShape)
                        .background(if (i == pager.currentPage) Gold else Gold.copy(alpha = 0.35f))
                )
            }
        }
    }
}

@Composable
private fun SceneView(sc: Scene) {
    val inf = rememberInfiniteTransition(label = "bob")
    val t by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bobValue",
    )
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(sc.top), Color(sc.bottom))))) {
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    sc.emojis.forEachIndexed { i, e ->
                        val k = if (i % 2 == 0) t else 1f - t
                        Text(e, fontSize = if (sc.emojis.size > 3) 54.sp else 76.sp, modifier = Modifier.offset(y = (k * -18f).dp))
                    }
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Cream.copy(alpha = 0.95f)),
                border = BorderStroke(2.dp, Gold),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    sc.text, Modifier.padding(18.dp), color = Ink,
                    fontSize = 20.sp, lineHeight = 34.sp, textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
