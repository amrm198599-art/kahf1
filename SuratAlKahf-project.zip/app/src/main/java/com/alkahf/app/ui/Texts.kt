package com.alkahf.app.ui

object Texts {
    const val PRIVACY_AR = """سياسة الخصوصية — تطبيق «سورة الكهف»

آخر تحديث: 2026

• لا يجمع التطبيق أي بيانات شخصية ولا يطلب إنشاء حساب.
• لا توجد إعلانات ولا أدوات تتبّع أو تحليلات.
• كل إعداداتك (حجم الخط، موضع القراءة، المظهر، والصوتيات المنزّلة) تُحفظ على جهازك فقط.
• يتصل التطبيق بالإنترنت لتنزيل: نص السورة والتفسير الميسر (مرة واحدة ثم يُحفظان على الجهاز)، وملفات التلاوة التي تختار تنزيلها أو بثّها أو استخدامها في الفيديو. المصادر: api.alquran.cloud وeveryayah.com. قد تسجّل هذه الخدمات عنوان IP كما في أي موقع، ولها سياساتها الخاصة.
• ميزة «إنشاء فيديو» تُنتج ملف فيديو على جهازك وتحفظه في معرض الصور/الفيديو؛ وإن اخترت صورة خلفية فإنها تُقرأ محلياً ولا تُرفع إلى أي مكان.
• الأذونات: الإنترنت (للتنزيل والبث)، الإشعارات (لإشعار التحكم بالتشغيل)، خدمة التشغيل في الخلفية (لتلاوة الصوت)، والتخزين على أندرويد 9 أو أقدم فقط (لحفظ الفيديو في المعرض).
• يمكنك حذف الصوتيات المنزّلة من شاشة الاستماع، أو حذف كل البيانات بحذف التطبيق.
• التطبيق غير موجّه للأطفال دون 13 عاماً بشكل خاص، ولا يجمع بياناتهم.

للتواصل: [ضع بريدك الإلكتروني هنا]"""

    const val PRIVACY_EN = """Privacy Policy — "Surat Al-Kahf" app

• The app collects no personal data and requires no account.
• No ads, no trackers, no analytics.
• Your settings (font size, reading position, theme, downloaded audio) stay on your device only.
• The app uses the internet to download the surah text and the Muyassar tafsir (once, then cached) and the recitation files you choose to stream, download or use in a video. Sources: api.alquran.cloud, everyayah.com. These services may log IP addresses like any website and have their own policies.
• The "Create video" feature produces a video file on your device and saves it to your gallery; a background image you pick is read locally and never uploaded.
• Permissions: Internet; notifications (playback controls); foreground media playback (audio); storage on Android 9 and below only (to save the video to the gallery).
• Delete downloaded audio from the Listen screen, or remove all data by uninstalling the app.

Contact: [put your email here]"""
}
