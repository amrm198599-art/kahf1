package com.alkahf.app.video

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.alkahf.app.audio.AudioStore
import com.alkahf.app.data.AyahItem
import com.alkahf.app.data.Reciter
import com.alkahf.app.data.Reciters
import com.alkahf.app.ui.arabicDigits
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max

/** ينشئ فيديو mp4 (صورة الآية + صوت القارئ) ويحفظه في معرض الهاتف. */
object VideoExporter {
    private const val W = 720
    private const val H = 1280
    private const val GOLD = 0xFFC9A227.toInt()
    private const val CREAM = 0xFFFBF6E6.toInt()

    private fun renderFrame(text: String, ayah: Int, reciter: Reciter, style: Int, bg: Bitmap?): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (style == 3 && bg != null) {
            val s = max(W / bg.width.toFloat(), H / bg.height.toFloat())
            val dw = bg.width * s
            val dh = bg.height * s
            c.drawBitmap(bg, null, RectF((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            c.drawColor(0x8C000000.toInt())
        } else {
            val cols = when (style) {
                1 -> intArrayOf(0xFF0D1B3D.toInt(), 0xFF2E4A7D.toInt())
                2 -> intArrayOf(0xFF5C430A.toInt(), 0xFFA8861C.toInt())
                else -> intArrayOf(0xFF0B4D2C.toInt(), 0xFF1E7A47.toInt())
            }
            val p = Paint()
            p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), cols[0], cols[1], Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
        }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD; this.style = Paint.Style.STROKE }
        line.strokeWidth = 6f
        c.drawRect(28f, 28f, W - 28f, H - 28f, line)
        line.strokeWidth = 2f
        c.drawRect(42f, 42f, W - 42f, H - 42f, line)

        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = GOLD; textSize = 54f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD); textAlign = Paint.Align.CENTER
        }
        c.drawText("سورة الكهف", W / 2f, 160f, title)

        val body = "$text ﴿${arabicDigits(ayah)}﴾"
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = CREAM; typeface = Typeface.SERIF }
        var size = 56f
        var layout: StaticLayout
        while (true) {
            tp.textSize = size
            layout = StaticLayout.Builder.obtain(body, 0, body.length, tp, W - 140)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, 1.6f)
                .build()
            if (layout.height <= 760 || size <= 22f) break
            size -= 2f
        }
        c.save()
        c.translate(70f, (H - layout.height) / 2f)
        layout.draw(c)
        c.restore()

        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = GOLD; textSize = 34f; typeface = Typeface.SERIF; textAlign = Paint.Align.CENTER
        }
        c.drawText("${reciter.name} — ${reciter.style}", W / 2f, H - 120f, foot)
        return bmp
    }

    private fun ensureAudio(ctx: Context, r: Reciter, n: Int, dir: File): File {
        val local = AudioStore.file(ctx, r.id, n)
        if (local.exists()) return local
        val out = File(dir, "a$n.mp3")
        val c = URL(Reciters.ayahUrl(r, n)).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        try {
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        } finally {
            c.disconnect()
        }
        return out
    }

    private fun durationUs(f: File): Long {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.absolutePath)
            return (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
        } finally {
            r.release()
        }
    }

    suspend fun export(
        ctx: Context,
        reciter: Reciter,
        ayahs: List<AyahItem>,
        style: Int,
        bg: Bitmap?,
        onStatus: suspend (String) -> Unit,
    ): String {
        val app = ctx.applicationContext
        val dir = File(app.cacheDir, "export")
        dir.deleteRecursively()
        dir.mkdirs()

        val videoItems = ArrayList<EditedMediaItem>()
        val audioItems = ArrayList<EditedMediaItem>()
        withContext(Dispatchers.IO) {
            ayahs.forEachIndexed { i, a ->
                onStatus("تجهيز الآية ${arabicDigits(a.n)} (${i + 1}/${ayahs.size})")
                val audio = ensureAudio(app, reciter, a.n, dir)
                val dur = durationUs(audio)
                if (dur <= 0L) throw IllegalStateException("ملف صوت غير صالح")
                val frame = renderFrame(a.text, a.n, reciter, style, bg)
                val png = File(dir, "f$i.png")
                png.outputStream().use { frame.compress(Bitmap.CompressFormat.PNG, 100, it) }
                frame.recycle()
                val imgItem = MediaItem.Builder().setUri(Uri.fromFile(png)).setMimeType(MimeTypes.IMAGE_PNG).build()
                videoItems.add(EditedMediaItem.Builder(imgItem).setDurationUs(dur).setFrameRate(30).build())
                val audItem = MediaItem.Builder().setUri(Uri.fromFile(audio)).setMimeType(MimeTypes.AUDIO_MPEG).build()
                audioItems.add(EditedMediaItem.Builder(audItem).build())
            }
        }

        onStatus("جاري إنشاء الفيديو… قد يستغرق دقيقة")
        val out = File(dir, "out.mp4")
        val composition = Composition.Builder(
            listOf(EditedMediaItemSequence(videoItems), EditedMediaItemSequence(audioItems))
        ).build()

        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Unit> { cont ->
                val t = Transformer.Builder(app)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    })
                    .build()
                t.start(composition, out.absolutePath)
                cont.invokeOnCancellation { t.cancel() }
            }
        }

        val name = "kahf_${ayahs.first().n}-${ayahs.last().n}_${System.currentTimeMillis() / 1000}.mp4"
        return withContext(Dispatchers.IO) { saveToGallery(app, out, name) }
    }

    private fun saveToGallery(ctx: Context, src: File, name: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SuratAlKahf")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw java.io.IOException("تعذّر إنشاء الملف في المعرض")
            resolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "SuratAlKahf")
            dir.mkdirs()
            val f = File(dir, name)
            src.copyTo(f, true)
            MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf("video/mp4"), null)
        }
        return name
    }
}
