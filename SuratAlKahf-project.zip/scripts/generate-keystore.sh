#!/usr/bin/env bash
# ينشئ مفتاح التوقيع ويطبع قيم GitHub Secrets. احتفظ بنسخة احتياطية من الملف وكلمات السر (لا يمكن تعويضه!).
set -euo pipefail
ALIAS="${1:-kahf}"
read -r -s -p "كلمة سر المفتاح (6+ أحرف): " PASS; echo
keytool -genkeypair -v -keystore release.jks -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=Surat Al-Kahf, O=Personal, C=EG"
echo; echo "أضف هذه الأسرار في GitHub: Settings > Secrets and variables > Actions"
echo "KEY_ALIAS=$ALIAS"
echo "KEYSTORE_PASSWORD و KEY_PASSWORD = كلمة السر التي أدخلتها"
echo "KEYSTORE_BASE64 ="
base64 -w0 release.jks 2>/dev/null || base64 release.jks
echo
