from PIL import Image, ImageDraw, ImageFont
import os
S=1024
FONT="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
GREEN=(11,77,44,255); GREEN2=(20,110,60,255); GOLD=(201,162,39,255); CREAM=(251,246,230,255)
def fg(size=S):
    im=Image.new("RGBA",(S,S),(0,0,0,0)); d=ImageDraw.Draw(im)
    # safe zone ~ 66%: book occupies x 270..754, y 230..794
    x0,y0,x1,y1=285,215,745,809
    d.rounded_rectangle((x0+14,y0+14,x1+14,y1+14),40,fill=(0,0,0,60))      # shadow
    d.rounded_rectangle((x0+30,y0+22,x1+10,y1+10),36,fill=CREAM)            # pages
    for i in range(5): d.line((x1+2-i*0,y0+60+i*0,x1+2,y1-40),fill=(210,200,170,255),width=1)
    d.rounded_rectangle((x0,y0,x1,y1),36,fill=GREEN)                        # cover
    d.rounded_rectangle((x0,y0,x0+46,y1),36,fill=(8,58,33,255))             # spine
    d.rounded_rectangle((x0+70,y0+34,x1-30,y1-34),22,outline=GOLD,width=8)  # border
    d.rounded_rectangle((x0+86,y0+50,x1-46,y1-50),16,outline=GOLD,width=3)
    cx=(x0+70+x1-30)//2
    # ornament (diamond + circle)
    cy=y0+150
    d.ellipse((cx-42,cy-42,cx+42,cy+42),outline=GOLD,width=6)
    d.polygon([(cx,cy-30),(cx+30,cy),(cx,cy+30),(cx-30,cy)],fill=GOLD)
    f1=ImageFont.truetype(FONT,92); f2=ImageFont.truetype(FONT,100)
    for txt,font,yy in (("سورة",f1,y0+300),("الكهف",f2,y0+420)):
        w=d.textlength(txt,font=font,direction="rtl",language="ar")
        d.text((cx-w/2,yy),txt,font=font,fill=GOLD,direction="rtl",language="ar")
    d.line((cx-110,y1-110,cx+110,y1-110),fill=GOLD,width=4)
    return im
def bg():
    im=Image.new("RGBA",(S,S),CREAM); d=ImageDraw.Draw(im)
    for r in range(520,0,-8):
        t=r/520; c=(int(251-14*(1-t)),int(246-20*(1-t)),int(230-40*(1-t)),255)
        d.ellipse((S//2-r,S//2-r,S//2+r,S//2+r),fill=c)
    return im
base="app/src/main/res"  # شغّله من جذر المشروع
dens={"mdpi":108,"hdpi":162,"xhdpi":216,"xxhdpi":324,"xxxhdpi":432}
F=fg(); B=bg()
for k,v in dens.items():
    p=f"{base}/mipmap-{k}"; os.makedirs(p,exist_ok=True)
    F.resize((v,v),Image.LANCZOS).save(f"{p}/ic_launcher_foreground.png")
    B.resize((v,v),Image.LANCZOS).convert("RGB").save(f"{p}/ic_launcher_background.png")
# Play Store icon 512
full=Image.alpha_composite(B,F).resize((512,512),Image.LANCZOS).convert("RGB"); full.save("play_store_icon_512.png")
